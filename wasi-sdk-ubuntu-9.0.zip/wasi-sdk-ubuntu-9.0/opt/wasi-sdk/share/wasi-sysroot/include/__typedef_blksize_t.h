#ifndef __wasm_basics___typedef_blksize_t_h
#define __wasm_basics___typedef_blksize_t_h

typedef long blksize_t;

#endif
